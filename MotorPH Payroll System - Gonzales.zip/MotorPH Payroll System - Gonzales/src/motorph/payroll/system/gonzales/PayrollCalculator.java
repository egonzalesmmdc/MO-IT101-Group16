/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorph.payroll.system.gonzales;


public class PayrollCalculator {
    public static void calculatePayroll(Employee employee, String month, int week) {
        DataHours dataHours = employee.getDataHours();
        Double[] hours = dataHours.getHours(month, week);

        if (hours == null) {
            System.out.println("No data available for " + month + " Week " + week);
            return;
        }

        
        double regularHours = hours[0];
        double overtimeHours = hours[1];
        double hourlyRate = employee.getHourlyRate();

        
        //Payment
        double basicPay = regularHours * hourlyRate;
        double overtimePay = overtimeHours * hourlyRate * 1.25;

        
        //Deductions
        double monthlyBasic = employee.getHourlyRate() * dataHours.getAssumedRegularHours() * 4;
        double weeklyBasic = monthlyBasic / 4;

        double sss = GovernmentContributions.calculateSSS(monthlyBasic) / 4;
        double philhealth = GovernmentContributions.calculatePhilhealth(monthlyBasic) / 4;
        double pagibig = GovernmentContributions.calculatePagIBIG(monthlyBasic) / 4;
        double withholdingTax = GovernmentContributions.calculateWithholdingTax(weeklyBasic) / 4;

        
        //Total
        double grossPay = basicPay + overtimePay;
        double totalDeductions = sss + philhealth + pagibig + withholdingTax;
        double netPay = grossPay - totalDeductions;

        //Payroll Statement
        System.out.println("\nPAYROLL STATEMENT");
        System.out.println("Employee: " + employee.getFullName());
        System.out.println("Employee #: " + employee.getEmployeeNumber());
        System.out.println("Position: " + employee.getPosition());
        System.out.println("Hourly Rate: PHP " + employee.getHourlyRate());
        System.out.println("-------------------------------------------------");
        System.out.println("Government Agency Details:");
        System.out.println("SSS #: " + employee.getSssNumber());
        System.out.println("PhilHealth #: " + employee.getPhilhealthNumber());
        System.out.println("TIN #: " + employee.getTinNumber());
        System.out.println("Pag-IBIG #: " + employee.getPagibigNumber());
        System.out.println("-------------------------------------------------");
        System.out.println("Period: " + month + " Week " + week);
        System.out.printf("Basic Pay: PHP %.2f\n", basicPay);
        System.out.printf("Overtime Pay: PHP %.2f\n", overtimePay);
        System.out.println("-------------------------------------------------");
        System.out.printf("SSS Deduction: PHP %.2f\n", sss);
        System.out.printf("PhilHealth Deduction: PHP %.2f\n", philhealth);
        System.out.printf("Pag-IBIG Deduction: PHP %.2f\n", pagibig);
        System.out.printf("Withholding Tax: PHP %.2f\n", withholdingTax);
        System.out.println("-------------------------------------------------");
        System.out.printf("Net Pay: PHP %.2f\n", netPay);
    }
}
