/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorph.payroll.system.gonzales;


import java.util.ArrayList;
import java.util.List;

public class EmployeeData {
     public static List<Employee> initializeEmployees() {
        List<Employee> employees = new ArrayList<>();

        
        employees.add(createEmployee(
            10001, "Garcia", "Manuel III", "Garcia101", "10/11/1983",
            "Chief Executive Officer", 535.71,
            new double[][]{{42.5, 2.5}, {43.5, 3.5}, {43.5, 3.5}, {43.5, 3.5}}, 
            "44-4506057-3", "820126853951", "442-605-657-000", "691295330870"
        ));

        employees.add(createEmployee(
            10002, "Lim", "Antonio", "Lim102", "6/19/1988",
            "Chief Operating Officer", 357.14, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "52-2061274-9", "331735646338", "683-102-776-000", "663904995411"
        ));

        employees.add(createEmployee(
            10003, "Aquino", "Bianca Sofia", "Aquino103", "8/4/1989",
            "Chief Finance Officer", 357.14, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "30-8870406-2", "177451189665", "971-711-280-000", "171519773969"
        ));
        
        employees.add(createEmployee(
            10004, "Reyes", "Isabella", "Reyes104", "6/16/1994",
            "Chief Marketing Officer", 357.14, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "40-2511815-0", "341911411254", "876-809-437-000", "416946776041"
        ));

        employees.add(createEmployee(
            10005, "Hernandez", "Eduard", "Hernandez105", "9/23/1989",
            "IT Operations and Systems", 313.51, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "50-5577638-1", "957436191812", "031-702-374-000", "952347222457"
        ));
        
        employees.add(createEmployee(
            10006, "Villanueva", "Andrea Mae", "Villanueva106", "2/14/1988",
            "HR Manager", 313.51, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "49-1632020-8", "382189453145", "317-674-022-000", "441093369646"
        ));
        
        employees.add(createEmployee(
            10007, "San Jose", "Brad", "SanJose107", "3/15/1996",
            "HR Team Leader", 255.80, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "40-2400714-1", "239192926939", "672-474-690-000", "210850209964"
        ));
        
        employees.add(createEmployee(
            10008, "Romualdez", "Alice", "Romualdez108", "5/14/1992",
            "HR Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "55-4476527-2", "545652640232", "888-572-294-000", "211385556888"
        ));
        
        employees.add(createEmployee(
            10009, "Atienza", "Rosie", "Atienza109", "9/24/1948",
            "HR Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "41-0644692-3", "708988234853", "604-997-793-000", "260107732354"
        ));
        
        employees.add(createEmployee(
            10010, "Alvaro", "Roderick", "Alvaro110", "3/30/1988",
            "Accounting Head", 313.51, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "64-7605054-4", "578114853194", "525-420-419-000", "799254095212"
        ));
         
        employees.add(createEmployee(
            10011, "Salcedo", "Anthony", "Salcedo111", "9/14/1993",
            "Payroll Manager", 302.53, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "26-9647608-3", "126445315651", "210-805-911-000", "218002473454"
        ));
         
        employees.add(createEmployee(
            10012, "Lopez", "Josie", "Lopez112", "1/14/1987",
            "Payroll Team Leader", 229.02, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "44-8563448-3", "431709011012", "218-489-737-000", "113071293354"
        ));
           
        employees.add(createEmployee(
            10013, "Farala", "Martha", "Farala113", "1/11/1942",
            "Payroll Rank and File", 142.86, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "45-5656375-0", "233693897247", "210-835-851-000", "631130283546"
        ));
          
        employees.add(createEmployee(
            10014, "Martinez", "Leila", "Martinez114", "7/11/1970",
            "Payroll Rank and File", 142.86, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "27-2090996-4", "515741057496", "275-792-513-000", "101205445886"
        ));
          
        employees.add(createEmployee(
            10015, "Romualdez", "Fredrick", "Romualdez115", "3/10/1985",
            "Account Manager", 318.45, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "26-8768374-1", "308366860059", "598-065-761-000", "223057707853"
        ));
          
        employees.add(createEmployee(
            10016, "Mata", "Christian", "Mata116", "10/21/1987",
            "Account Team Leader", 255.80, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "49-2959312-6", "824187961962", "103-100-522-000", "631052853464"
        ));
          
        employees.add(createEmployee(
            10017, "De Leon", "Selena", "DeLeon117", "2/20/1975",
            "Account Team Leader", 249.11, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "27-2090208-8", "587272469938", "482-259-498-000", "719007608464"
        ));
          
        employees.add(createEmployee(
            10018, "San Jose", "Allison", "SanJose118", "6/24/198",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "45-3251383-0", "745148459521", "121-203-336-000", "114901859343"
        ));
          
        employees.add(createEmployee(
            10019, "Rosario", "Cydney", "Rosario119", "10/6/1996",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "49-1629900-2", "579253435499", "122-244-511-000", "265104358643"
        ));
          
        employees.add(createEmployee(
            10020, "Bautista", "Mark", "Bautista120", "2/12/1991",
            "Account Rank and File", 138.39, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "49-1647342-5", "399665157135", "273-970-941-000", "260054585575"
        ));
          
        employees.add(createEmployee(
            10021, "Lazaro", "Darlene", "Lazaro121", "11/25/1985",
            "Account Rank and File", 138.39, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "45-5617168-2", "606386917510", "354-650-951-000", "104907708845"
        ));
          
        employees.add(createEmployee(
            10022, "Delos Santos", "Kolby", "DelosSantos122", "2/26/1980",
            "Account Rank and File", 142.86, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "52-0109570-6", "357451271274", "187-500-345-000", "113017988667"
        ));
          
        employees.add(createEmployee(
            10023, "Santos", "Vella", "Santos123", "12/31/1983",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "52-9883524-3", "548670482885", "101-558-994-000", "360028104576"
        ));
          
        employees.add(createEmployee(
            10024, "Del Rosario", "Tomas", "DelRosario124", "12/18/1978",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "45-5866331-6", "953901539995", "560-735-732-000", "913108649964"
        ));
          
        employees.add(createEmployee(
            10025, "Tolentino", "Jacklyn", "Tolentino125", "5/19/1984",
            "Account Rank and File", 142.86, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "47-1692793-0", "753800654114", "841-177-857-000", "210546661243"
        ));
          
        employees.add(createEmployee(
            10026, "Gutierrez", "Percival", "Gutierrez126", "12/18/1970",
            "Account Rank and File", 147.32, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "40-9504657-8", "797639382265", "502-995-671-000", "210897095686"
        ));
          
        employees.add(createEmployee(
            10027, "Manalaysay", "Garfield", "Manalaysay127", "8/28/1986",
            "Account Rank and File", 147.32, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "45-3298166-4", "810909286264", "336-676-445-000", "211274476563"
        ));
          
        employees.add(createEmployee(
            10028, "Villegas", "Lizeth", "Villegas128", "12/12/1981",
            "Account Rank and File", 142.86, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "40-2400719-4", "934389652994", "210-395-397-000", "122238077997"
        ));
          
        employees.add(createEmployee(
            10029, "Ramos", "Carol", "Ramos129", "8/20/1978",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "60-1152206-4", "351830469744", "395-032-717-000", "212141893454"
        ));
          
        employees.add(createEmployee(
            10030, "Maceda", "Emelia", "Maceda130", "4/14/1973",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "54-1331005-0", "465087894112", "215-973-013-000", "515012579765"
        ));
          
        employees.add(createEmployee(
            10031, "Aguilar", "Delia", "Aguilar131", "1/27/1989",
            "Account Rank and File", 133.93, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "52-1859253-1", "136451303068", "599-312-588-000", "110018813465"
        ));
          
        employees.add(createEmployee(
            10032, "Castro", "John Rafael", "Castro132", "2/9/1992",
            "Sales & Marketing", 313.51, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "26-7145133-4", "601644902402", "404-768-309-000", "697764069311"
        ));
          
        employees.add(createEmployee(
            10033, "Martinez", "Carlos Ian", "Martinez133", "11/16/1990",
            "Supply Chain and Logistics", 313.51, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "11-5062972-7", "380685387212", "256-436-296-000", "993372963726"
        ));
          
        employees.add(createEmployee(
            10034, "Santos", "Beatriz", "Santos134", "8/7/1990",
            "Customer Service and Relations", 313.51, 
            new double[][]{{46.5, 6.5}, {45.5, 5.5}, {45.5, 5.5}, {45.5, 5.5}}, 
            "20-2987501-5", "918460050077", "911-529-713-000", "874042259378"
        ));
        
        return employees;
    }

    private static Employee createEmployee(int empId, String lastName, String firstName, 
                                          String password, String birthday, String position, double hourlyRate, 
                                          double[][] juneHours, String sssNumber, 
                                          String philhealthNumber, String tinNumber, 
                                          String pagibigNumber) {
        
        
        DataHours dataHours = new DataHours (empId, 40);
        for (int week = 0; week < juneHours.length; week++) {
            dataHours.addHours("June", week + 1, juneHours[week][0], juneHours[week][1]);
        }

        
        
        String[] otherMonths = {"July", "August", "September", "October", "November", "December"};
        for (String month : otherMonths) {
            for (int week = 1; week <= 4; week++) {
                dataHours.addHours(month, week, 0.0, 0.0);
            }
        }

        return new Employee(empId, lastName, firstName, password, birthday, position, hourlyRate, 
                           dataHours, sssNumber, philhealthNumber, tinNumber, pagibigNumber, null);
    }

    public static Employee getEmployee(int empId, List<Employee> employees) {
        for (Employee emp : employees) {
            if (emp.getEmployeeNumber() == empId) {
                return emp;
            }
        }
        return null; 
    }
}
