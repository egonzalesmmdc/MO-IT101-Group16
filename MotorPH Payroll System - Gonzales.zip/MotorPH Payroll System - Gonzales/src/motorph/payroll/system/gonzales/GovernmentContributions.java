/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorph.payroll.system.gonzales;


public class GovernmentContributions {
      public static double calculateSSS(double monthlySalary) {
        if(monthlySalary < 3250) return 135.00;
        if(monthlySalary < 3750) return 157.50;
        if(monthlySalary < 4250) return 180.00;
        if(monthlySalary < 4750) return 202.50;
        if(monthlySalary < 5250) return 225.00;
        if(monthlySalary < 5750) return 247.00;
        if(monthlySalary < 6250) return 270.00;
        if(monthlySalary < 6750) return 292.50;
        if(monthlySalary < 7250) return 315.00;
        if(monthlySalary < 7750) return 337.50;
        if(monthlySalary < 8250) return 360.00;
        if(monthlySalary < 8750) return 382.50;
        if(monthlySalary < 9250) return 405.00;
        if(monthlySalary < 9750) return 427.50;
        if(monthlySalary < 10250) return 450.00;
        if(monthlySalary < 10750) return 472.50;
        if(monthlySalary < 11250) return 495.00;
        if(monthlySalary < 11750) return 517.50;
        if(monthlySalary < 12250) return 540.00;
        if(monthlySalary < 12750) return 562.50;
        if(monthlySalary < 13250) return 585.00;
        if(monthlySalary < 13750) return 607.50;
        if(monthlySalary < 14250) return 630.00;
        if(monthlySalary < 14750) return 652.50;
        if(monthlySalary < 15250) return 675.00;
        if(monthlySalary < 15750) return 697.50;
        if(monthlySalary < 16250) return 720.00;
        if(monthlySalary < 16750) return 742.50;
        if(monthlySalary < 17250) return 765.00;
        if(monthlySalary < 17750) return 787.50;
        if(monthlySalary < 18250) return 810.00;
        if(monthlySalary < 18750) return 832.50;
        if(monthlySalary < 19250) return 855.00;
        if(monthlySalary < 19750) return 877.50;
        if(monthlySalary < 20250) return 900.00;
        if(monthlySalary < 20750) return 922.50;
        if(monthlySalary < 21250) return 945.00;
        if(monthlySalary < 21750) return 967.50;
        if(monthlySalary < 22250) return 990.00;
        if(monthlySalary < 22750) return 1012.50;
        if(monthlySalary < 23250) return 1035.00;
        if(monthlySalary < 23750) return 1057.50;
        if(monthlySalary < 24250) return 1080.00;
        if(monthlySalary < 24750) return 1102.50;
        if(monthlySalary > 24750) return 1125.00;
          return 1125.00;
    }

      
      
      
    public static double calculatePhilhealth(double monthlySalary) {
        double premium = monthlySalary * 0.03;
        return Math.min(Math.max(premium, 300), 1800) / 2; 
    }

    
    
    
    
    public static double calculatePagIBIG(double monthlySalary) {
        return (monthlySalary > 1500) ? monthlySalary * 0.02 : monthlySalary * 0.01;
    }

    
    
    
    public static double calculateWithholdingTax(double taxableIncome) {
        if(taxableIncome <= 20832) return 0;
        if(taxableIncome <= 33333) return (taxableIncome - 20833) * 0.20;
        if(taxableIncome <= 66667) return (taxableIncome - 33333) * 0.25 + 2500;
        if(taxableIncome <= 166667) return (taxableIncome - 66667) * 0.30 + 10833;
        if(taxableIncome <= 666667) return (taxableIncome - 166667) * 0.32 + 40833.83;
        return (taxableIncome - 666667) * 0.35 + 200833.33;
    }
}

