/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorph.payroll.system.gonzales;


public class Employee {
    private final int employeeNumber;
    private final String lastName;
    private final String firstName;
    private final String password;
    private final String position;
    private final String birthday;
    private final double hourlyRate;
    private final DataHours dataHours;
    private final String sssNumber;
    private final String philhealthNumber;
    private final String tinNumber;
    private final String pagibigNumber;

    public Employee(int employeeNumber, String lastName, String firstName, String password, String birthday, String position, double hourlyRate, DataHours dataHours, String sssNumber, String philhealthNumber, String tinNumber, String pagibigNumber, java.lang.String birthday1) {
        this.employeeNumber = employeeNumber;
        this.lastName = lastName;
        this.firstName = firstName;
        this.password = password;
        this.position = position;
        this.birthday = birthday1;
        this.hourlyRate = hourlyRate;
        this.dataHours = dataHours;
        this.sssNumber = sssNumber;
        this.philhealthNumber = philhealthNumber;
        this.tinNumber = tinNumber;
        this.pagibigNumber = pagibigNumber;
    }


    public int getEmployeeNumber() {
        return employeeNumber;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getPosition() {
        return position;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public String getSssNumber() {
        return sssNumber;
    }

    public String getPhilhealthNumber() {
        return philhealthNumber;
    }

    public String getTinNumber() {
        return tinNumber;
    }

    public String getPagibigNumber() {
        return pagibigNumber;
    }

    public DataHours getDataHours() {
        return dataHours;
    }

    
    public boolean validatePassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }
}
