/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorph.payroll.system.gonzales;


import java.util.HashMap;
import java.util.Map;

public class DataHours {
    private final int employeeNumber;
    private final int assumedRegularHours; 
    private final Map<String, Map<Integer, Double[]>> monthlyHours; 

    
    public DataHours(int employeeNumber, int assumedRegularHours) {
        this.employeeNumber = employeeNumber;
        this.assumedRegularHours = assumedRegularHours;
        this.monthlyHours = new HashMap<>();
    }

    
    public void addHours(String month, int week, double regularHours, double overtime) {
        monthlyHours.computeIfAbsent(month, k -> new HashMap<>())
                    .put(week, new Double[]{regularHours, overtime});
    }

   
    public Double[] getHours(String month, int week) {
        if (monthlyHours.containsKey(month)) { 
            return monthlyHours.get(month).get(week);
        }
        return null; 
    }

    
    public Map<String, Map<Integer, Double[]>> getAllMonthlyHours() {
        return monthlyHours;
    }

    
    public int getEmployeeNumber() {
        return employeeNumber;
    }

   
    public int getAssumedRegularHours() {
        return assumedRegularHours;
    }
}   
